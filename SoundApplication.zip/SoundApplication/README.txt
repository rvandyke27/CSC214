
Rebecca Van Dyke
rvandyke@u.rochester.edu
CSC 214 Assignment 8
TA: Julian Weiss

The requirements for this assignment were to implement a simple visual (master detail) display of audio files using SoundPool. I chose to use audio snippets from the game Undertale. We were also required to create some custom styles that appear differently on different versions of android.