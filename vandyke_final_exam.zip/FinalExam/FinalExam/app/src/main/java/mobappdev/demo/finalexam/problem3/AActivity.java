package mobappdev.demo.finalexam.problem3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import mobappdev.demo.finalexam.R;

public class AActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a);
    }
}
