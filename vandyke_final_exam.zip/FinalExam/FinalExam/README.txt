
Rebecca Van Dyke
rvandyke@u.rochester.edu
Final Exam

I affirm that I will not give or receive any unauthorized help on this exam, and that all work will be my own.