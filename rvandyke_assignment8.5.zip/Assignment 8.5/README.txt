
Rebecca Van Dyke
rvandyke@u.rochester.edu
CSC 214 Assignment 8.5: Redoing Assignment 6
TA: Julian Weiss

The purpose of this assignment was to implement lists in android in two ways; using a listview and a recyclerview. Viewpager and Dialog fragments were also used to display a collection of my Model items, bhangra teams.